﻿using Fendahl_API_Profile.Models;
using Microsoft.AspNetCore.Mvc;

namespace Fendahl_API_Profile.Services
{
    public interface IProfileServices
    {
        Profile GetProfileById(int id);
        IEnumerable<Profile> GetAllProfiles();
        Profile CreateProfile(Profile profile);
        bool UpdateProfileById(int id,Profile profile);
        bool DeleteProfile(int id);
    }
}
