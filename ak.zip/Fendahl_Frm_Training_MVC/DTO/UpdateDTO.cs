﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fendahl_Frm_Training_MVC.DTO
{
    public class UpdateDTO
    {
        public string NAME { get; set; }
        public string MOBILE_NUMBER { get; set; }
    }
}